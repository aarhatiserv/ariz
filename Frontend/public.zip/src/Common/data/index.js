import { filterProduct, catlogDeals, shopProducDetails } from "./CatalogData";

export { filterProduct, catlogDeals, shopProducDetails };
