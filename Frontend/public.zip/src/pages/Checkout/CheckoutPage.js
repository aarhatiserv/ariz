import React from "react";
import Checkout from "../../components/Checkout/Checkout";

function CheckoutPage() {
  return (
    <div>
      <Checkout />
    </div>
  );
}

export default CheckoutPage;
