import React from "react";

function Banner() {
  return (
    <div>
      <div class="  ">
        {/* <div
          class="relative flex flex-wrap  px-4 py-2 sm:flex-nowrap sm:items-center sm:justify-center sm:gap-3 sm:pr-8 md:px-8"
          style={{ background: " #E59898" }}
        >
          <div class="order-1 mb-6 inline-block w-11/12 max-w-screen-sm text-sm text-center text-white sm:order-none sm:mb-0 sm:w-auto md:text-base">
            Free Delivery on orders over $1499. Don't miss discount.
          </div>
        </div> */}
      </div>
    </div>
  );
}

export default Banner;
