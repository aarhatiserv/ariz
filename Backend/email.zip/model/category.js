const mongoose = require("mongoose");

const differentSchema = new mongoose.Schema({
  category: {
    type: String,
  },
  subcategory: [String],
  subcategory1: [String],
  imageUrl: {
    type: String,
  },
});

module.exports = mongoose.model("Different", differentSchema);
