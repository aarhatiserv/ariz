const express = require("express");
const app = express();
const cors = require("cors");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const paymentRoute = require("./controller/payment");

const userRoute = require("./router/userRoute");
const newArrival = require("./router/newArrival");
const authRoute = require("./router/authRoute");
const userProduct = require("./router/userProduct");

const trending = require("./router/trending");
const product = require("./router/product");
const coupon = require("./router/coupon");
const category = require("./router/category");
const cart = require("./router/cart");

app.use(cors());
app.use(bodyParser.json({ limit: "50mb" }));
app.use(bodyParser.urlencoded({ limit: "50mb", extended: true }));

const port = process.env.PORT || 5000;

const uri =
  "mongodb+srv://arizdatabase:FHU3RA9govcDwNbf@cluster0.sufevhr.mongodb.net/";

mongoose.connect(uri, { useNewUrlParser: true }, () =>
  console.log("Connected to DB")
);

//Middlewares
app.use(express.json());

//Route Middlewares
app.use("/api/razorpay", paymentRoute);
app.use("/api/user", userRoute);
app.use("/api/auth", authRoute);
app.use("/api/newArrival", newArrival);
app.use("/api/userProduct", userProduct);
app.use("/api/trending", trending);
app.use("/api/product", product);
app.use("/api/coupon", coupon);
app.use("/api/category", category);
app.use("/api/cart", cart);

// Callback function to listen to changes unless manually exited.
app.listen(port, () => {
  console.log(`Welcome to the tech world at PORT: ${port}`);
});
//the end
